export interface Member {
    name: string;
    color: string;
}