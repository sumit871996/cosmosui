import { Collection } from 'backbone';
import { Idea } from '../shapes/idea';

export default class IdeaCollection extends Collection<Idea> {

}
